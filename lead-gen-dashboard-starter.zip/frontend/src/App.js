
import React from 'react';

function App() {
  return (
    <div>
      <h1>Lead Gen Dashboard</h1>
      <p>Your frontend is running!</p>
    </div>
  );
}

export default App;
