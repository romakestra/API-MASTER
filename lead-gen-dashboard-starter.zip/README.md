# Lead Gen Dashboard

Basic full-stack template with Express backend and React frontend.
